class Problem:
    def __init__(self):
        self.text = ''


