class Pattern:
    def __init__(self):
        self.text = ''
        self.number_ranges = 0
        self.number_domains = 0
        self.number_properties = 0